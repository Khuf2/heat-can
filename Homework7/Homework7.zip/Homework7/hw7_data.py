text_entries = [ ["Hello, Traveler!", "Traveler"], ["mineminemineminemine", "mine"], ["$20.00", "$"], ["20% or 30%", "%"]]

blitz_matrix = [ [ ["Mario"] , "Welcome, Mario." ], [ ["Mario", "Luigi"], "Welcome, Mario. And welcome, Luigi." ] ]
count_matrix = [ [text_entries[0], 1], [text_entries[1], 5], [text_entries[2], 1], [text_entries[3], 2] ]
replace_matrix = [ [text_entries[0], "Hello, &!"], [text_entries[1], "&&&&&"], [text_entries[2], "&20.00"], [text_entries[3], "20& or 30&"] ]


