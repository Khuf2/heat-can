a = [ 1, 2, 3, 4, 5 ]

nth_matrix = [ [a, 1], [a, 2], [a, 4], [a, 5] ]

a = [ "Aristophanes",  "Aeschylus", "Demosthenes" ]
b = [ "Ronald", "Jim", "McDonald" ]
c = [ "Kaka", "Doodle", "Doo"]

name_matrix = [ [a, "Aristophanes A. Demosthenes"], [b, "Ronald J. McDonald"], [c, "Kaka D. Doo"] ]

