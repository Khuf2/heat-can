# Homework 3 - 6/20/20
# Lists, Loops, Conditionals
# This one will be fairly challenging, but I will walk you through it carefully. There are only 2 problems.

# Testing:
# Rename this file to hw3_submission.py
# To test in Terminal, simply type:
# python hw3_submission.py
# Or perform your own tests within this file, but be sure to delete them in your final tests for accuracy.

# Final Scoring:
# When you finish, navigate to your code directory in Terminal and run with python hw3_tests.py
# This uses your code in this file (if you renamed it) and prints test results.

# The list you will use for your testing is this one here:
list = [2, 4, 6, 8, 10]

# (Medium) Write the code for two functions, swap() and manualReverse().

# swap()
# In a list, swaps the value at index a with the value at index b.
def swap(list, a, b):
    # Your code starts here. 
    return None


# manualReverse() 
# Reverses the values in an array.
# You are NOT allowed to use reverse().
# Hint: You can use your swap method from above, i.e. swap(list, a, b).
def manualReverse(list):
    # Your code starts here
    return None


